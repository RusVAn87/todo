import { RootState } from "../app/store";

export const saveToLocalStorage = (state: RootState) => {
    try {
        console.log(state);

        const appState = JSON.stringify(state)

        localStorage.setItem('appState', appState)

    } catch (error) {
        console.warn(error)
    }

}

export const loadFromLocalStorage = () => {
    try {
        const appState = localStorage.getItem('appState')

        if (!appState) return undefined

        return JSON.parse(appState)
    } catch (error) {
        console.warn(error);
        return undefined
    }
}