import type { PreloadedState } from "@reduxjs/toolkit";
import type { RootState } from "../app/store";

const LS_KEY = "appState";

export function saveToLocalStorage(state: RootState) {
  try {
    localStorage.setItem(LS_KEY, JSON.stringify(state));
  } catch {}
}

export function loadFromLocalStorage(): PreloadedState<RootState> | undefined {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (!raw) return undefined;
    return JSON.parse(raw) as PreloadedState<RootState>;
  } catch {
    return undefined;
  }
}
